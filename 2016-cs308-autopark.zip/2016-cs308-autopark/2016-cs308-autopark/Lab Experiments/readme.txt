Group A 
Abhishek Thakur: (120050008)
Syamantak Naskar: (120050016)

Group B
Rajesh Roshan Behera: (120050079)
B Soma Naik: (120050080)