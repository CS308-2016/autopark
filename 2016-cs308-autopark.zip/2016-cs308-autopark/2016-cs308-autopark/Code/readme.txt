2016 - CS308  Group X : Project README TEMPLATE 
================================================ 
 
Group Info: 
------------ 
+   Abhishek Thakur (120050008) 
+   Syamantak Naskar (120050016) 
+   Rajesh Roshan Behera (120050079) 
+   B Soma Naik (120050080) 
 
Extension Of 
------------ 
 
No we have not extended our project from any other past projects.  
 
Project Description 
------------------- 
 
AutoPark is basically an automated parking manager. 
It consists of a parking lot and a booth at the entrance of it.  
When a car enters we process its image and figure out what type of car it is.
There are certain no. of spots reserved for each type of car.
If a slot is empty then a rfid tag is issued to the vehicle and the user goes and parks in it.
If no slot is available then no tag is issued.
We also measure the time for which a user was parked.
There is also a gate at the entrance of the parking lot which only opens when a car is issued a tag.
Since we had only 1 rfid sensor so we distinguished between the type of parking space using led light.
We used 2 types of cars i.e. car1 and car2.
If a car of type 1 was parked then green light would glow and if a car of type 2 was parked then a red light would glow.
 
Technologies Used 
------------------- 
 
+   MATLAB  
 
Installation Instructions 
========================= 
 
+ [MATLAB](http://in.mathworks.com/products/matlab/index.html?s_tid=gn_loc_drop) 
 
 
Demonstration Video 
=========================  
https://www.youtube.com/watch?v=ntKBT7AY4GA&feature=youtu.be

References 
=========== 
 
Please give references to importance resources.  
 
+ [eYantra DVD](https://drive.google.com/folderview?id=0BwLmQGS-3ITBdzE2dXo5TXF4U0E&usp=sharing)